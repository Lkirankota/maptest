import { Component, ViewChild } from '@angular/core';
import { ElementRef } from "@angular/core";
//import { Geolocation } from '@ionic-native/geolocation/ngx';

declare var google: any;

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
   @ViewChild('map') mapElement: ElementRef<1>;
   @ViewChild('directionsPanel') directionsPanel:ElementRef<1>;
    map: any;

    constructor() {
var self=this;
setTimeout(function() {
    self.loadMap();
        self.startNavigating();

}, 1000);
    }

    ionViewDidLoad(){

      
    }

    loadMap(){
debugger;
        let latLng = new google.maps.LatLng(-34.9290, 138.6010);

        let mapOptions = {
          center: latLng,
          zoom: 15,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }

        this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);

    }

    startNavigating(){

        let directionsService = new google.maps.DirectionsService;
        let directionsDisplay = new google.maps.DirectionsRenderer;

        directionsDisplay.setMap(this.map);
       directionsDisplay.setPanel(this.directionsPanel.nativeElement);

        directionsService.route({
            origin: 'adelaide',
            destination: 'adelaide oval',
            travelMode: google.maps.TravelMode['DRIVING']
        }, (res, status) => {

            if(status == google.maps.DirectionsStatus.OK){
                directionsDisplay.setDirections(res);
            } else {
                console.warn(status);
            }

        });

    }
//   @ViewChild('map') mapElement: ElementRef;
// map: any;
// marker: any;
//   constructor(private geolocation: Geolocation) {}
 
// setupmap(){
//   this.geolocation.getCurrentPosition().then((resp) => {
// this.loadMap(resp.coords.latitude,resp.coords.longitude)
// }).catch((error) => {
//   console.log('Error getting location', error);
// });
// }

// loadMap(latitude,longitude) {
//     let latLng = new google.maps.LatLng(latitude,longitude);
//     this.map = new google.maps.Map(document.getElementById('map'), {
//       zoom: 15,
//       center: latLng,
//     });
//   this.updatemarker(latLng);
//   }

//   updatemarker(latLng: any) {
//     if (this.marker) {
//       this.marker.setMap(null);
//     }
//     var latlngbounds = new google.maps.LatLngBounds();
//     var _self = this;
//     setTimeout(function () {
//       _self.marker = new google.maps.Marker({ map: _self.map, position: latLng });
//       _self.marker.setMap(_self.map);
//       latlngbounds.extend(_self.marker.position);
//       _self.map.setCenter(latlngbounds.getCenter());
//       _self.map.fitBounds(latlngbounds);
//     }, 100);
//   }
}
